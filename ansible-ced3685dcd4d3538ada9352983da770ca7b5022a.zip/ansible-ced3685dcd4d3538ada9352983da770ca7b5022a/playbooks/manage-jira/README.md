## Jira Project Playbook
This playbook is used to automate the creation of project on Jira.

### Example
Please refer to the [roles](../../roles/manage-jira/README.md) directory for information regarding the variables required to run this playbook.

### Running the playbook
`$ ansible-playbook -i inventory playbook.yaml`

## Confluence Space Playbook
This playbook is used to copy confluence space from one location to another.

### Example
Please refer to the [roles](../../roles/manage-confluence-space/README.md) directory for information regarding the variables required to run this playbook.

### Running the playbook
`$ ansible-playbook -i invetory playbook.yaml`

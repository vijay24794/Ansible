ansible-example-role
=========

This is an example role 

It showcases how the role should be structured and howto configure basic tests with Travis and Molecule when commiting to https://github.ibm.com/Continuous-Engineering/ 

This role ensures the package in pgk_list is installed and service in svc_list is started and enabled

It comes with configured basic molecule tests (lint, community role standards, idempotency etc.) and a small written test
'molecule/default/tests/test_default.py' to spawn a docker with configured image and check if the services defined are realy up after playbook execution.

Requirements
------------
None

Role Variables
--------------
Currently pkg_list and svc_list, they default to:

    pkg_list:
	- httpd
	- ntp
    svc_list:
	- httpd
	- ntpd

Dependencies
------------
None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables
passed in as parameters) is always nice for users too:

    - hosts: all
      roles:
         - { role: ansible-example-role }

License
-------

BSD

Author Information
------------------
Grzegorz Koper 

Travis Build Info
-----------------
[![Build Status](https://travis.ibm.com/grzegorz-koper/ansible-example-role.svg?branch=master)](https://travis.ibm.com/grzegorz-koper/ansible-example-role)
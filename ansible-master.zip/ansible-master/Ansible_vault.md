# Ansible VAULT

The Ansible Vault is used to store secrets in the yml file 

```
├── roles
│   └── secretcontent
│       ├── tasks
│       │   └── main.yml
│       └── vars
│           └── text.yml
└── vaultdemo.yml

```




# About
We're using [Semantic Versioning](http://semver.org/) and following [this definition](http://keepachangelog.com/en/0.3.0/) of a change log

# Released

# [v1.0.0] - 30 March 2017

## Added
- Initial release per the [CASL Trello Board](https://trello.com/b/wPeLg5dK/container-automation-solutions-lab)

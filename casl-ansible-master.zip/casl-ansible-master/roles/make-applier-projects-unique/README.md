# make-applier-projects-unique

This content has been moved to https://github.com/redhat-cop/openshift-applier


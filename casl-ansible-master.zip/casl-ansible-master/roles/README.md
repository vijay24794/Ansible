== The rhc-ose roles implementations

Below are the variables[Required and Optional] for each of the defined roles. They must be defined in the inventory files when running the related ansible playbook.

##Roles:

###dns

  - Required
    -
    -
    -
  - Optional
    -
    -
    -


###openshift-provision

  - Required
    -
    -
    -
  - Optional
    -
    -
    -

###openstack-create

  - Required
    -
    -
    -
  - Optional
    -
    -
    -

###registry

  - Required
    -
    -
    -
  - Optional
    -
    -
    -

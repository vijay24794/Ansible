# openshift-pv-cleanup

The purpose of this role is to clean up persistent volumes in a cluster before decommisioning a cluster.

## Usage

```
ansible-playbook -i inventory roles/openshift-pv-cleanup/test/main.yml
```

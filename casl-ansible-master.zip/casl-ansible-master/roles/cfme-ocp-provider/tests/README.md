# Instructions

1. Ensure the 'oc' client is part of your path 
2. Login as a cluster-admin on the OpenShift cluster
3. Execute with ansible, i.e.:

```
  > ansible-playbook -i inventory test.yml --connection=local
```

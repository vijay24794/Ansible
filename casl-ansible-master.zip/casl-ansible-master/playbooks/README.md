# The CASL Ansible playbooks

## openshift-cluster-seed.yml (openshift-applier)

This playbook (and supporting components) have been moved to a separate repo: https://github.com/redhat-cop/openshift-applier
